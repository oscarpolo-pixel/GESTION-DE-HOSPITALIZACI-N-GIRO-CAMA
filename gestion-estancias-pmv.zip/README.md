# Gestión de Estancias y Giro de Cama — PMV

Aplicación web local de demostración para seguimiento operativo de estancias hospitalarias. Todos los datos incluidos son ficticios.

## Abrir la aplicación

1. Abra `index.html` con un navegador moderno (Edge, Chrome o Firefox).
2. No requiere instalación, internet ni servidor.

## Incluye

- Dashboard e indicadores operativos.
- 35 pacientes ficticios, en rangos de estancia variados.
- Registro de pacientes y actuaciones de gestión.
- Historial por paciente, alertas, filtros y módulo de giro de cama.
- Exportación de CSV y persistencia local con `LocalStorage`.
- Umbrales configurables para alertas operativas.

## Nota de uso responsable

La aplicación apoya el seguimiento administrativo y asistencial. No diagnostica, no indica tratamientos y no determina altas: la validación de egreso corresponde siempre al personal clínico autorizado.

## Restablecer demo

Use **Configuración → Restablecer datos ficticios** para recuperar la cohorte inicial. Esto borra los cambios guardados por el navegador para esta aplicación.
